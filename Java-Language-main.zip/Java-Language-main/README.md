# Java-Language
Java is computer programming language which is used to develop software's and JAVA is "Just Another Virtual Accelarator".
