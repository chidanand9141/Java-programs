package pgm_on_Strings;

public class Hello_java_double_quoat 
{

	public static void main(String[] args) 
	{
		String str="\"Hello java\"";
		String str1=str; //swap
		System.out.println(str1);
	

	}

}
