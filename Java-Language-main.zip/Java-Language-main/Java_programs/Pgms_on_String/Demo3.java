// WAP on String method with parameter
package Pgms_on_String;

public class Demo3 
{
	static void call(String str)
	{
		System.out.println("This is String method with parameter:"+str);
	}
	public static void main(String[] args) 
	{
		call("Hey I am String");
		
	}

}
