                        //WAP display the String name
package Pgms_on_String;

public class Demo 
{
 public static void main(String[] args) 
 {
	 String name="Hi This is String";
	 System.out.println(name);
	
 }
}
