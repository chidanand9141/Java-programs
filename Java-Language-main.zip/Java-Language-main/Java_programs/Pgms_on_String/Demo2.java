                        //****str.replace()**** it is used to replace the string character
package Pgms_on_String;

public class Demo2 
{
 public static void main(String[] args) 
 {
	String str="NAGS";
	System.out.println(str.replace('S','U'));
 }
}
