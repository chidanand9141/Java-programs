                   // WAP on String Display Hello This is Java Programming
package Pgms_on_String;

public class Demo1 
{
  public static void main(String[] args) 
  {
	String str="Hello This is Java Programming";
	System.out.println(str);
  }
}
