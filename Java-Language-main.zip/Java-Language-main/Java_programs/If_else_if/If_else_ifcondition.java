package If_else_if;

 class If_else_ifcondition 
 {
	 public static void main(String[] args)
	 {
		 int a=100;
		 int b=200;
		 
		 if(a>=b)
		 {
			 System.out.println("a is greatter");
		 }
		 else if(a<=b)
		 {
			 System.out.println("a is lesser");
	     }
		 else
		 {
			 System.out.println("b is lesser");
		 }
	 }

 }
