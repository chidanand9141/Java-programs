                                  //*******Sum of Array Elements********
package Pgms_on_Array;
                       
public class Sample3
{
	static void array(int[] arr)
	{
		int sum=0;
		for(int i=0; i<=arr.length; i++)
		{
		  sum=sum+i;
		}
		System.out.println("The Sum of all array elements are:"+sum);
	}
	public static void main(String[] args) 
	{
		int[] arr={1,2,3,4,5};
		      array(arr);
		
	}

}
