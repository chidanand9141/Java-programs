package If;

class If_condition 
{
  public static void main(String[] args)
  {
	int x=100;
	int y=200;
	
	if(x<y)
	{
		System.out.println("Yes, X is less");
	}
	
  }
}
