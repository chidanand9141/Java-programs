package If_else;

class If_elsecondition 
{
  public static void main(String[] args)
  {
	  int a=100;
	  int b=200;
	  
	  if(a<=b)
	  {
		  System.out.println("a is less");
	  }
	  else
	  {
		  System.out.println("b is less");
	  }
  }
}
