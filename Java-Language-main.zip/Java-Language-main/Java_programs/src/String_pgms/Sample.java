package String_pgms;

public class Sample {
	public static void main(String[] args) {
		String str="This is String";
		System.out.println(str);
	}

}
