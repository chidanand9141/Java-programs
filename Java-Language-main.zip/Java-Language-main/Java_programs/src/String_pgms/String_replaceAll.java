package String_pgms;

public class String_replaceAll {
public static void main(String[] args) {
	String str="Hello   Good  Morning....!";
	System.out.println(str.replaceAll(" +"," "));
}
}
