package String_pgms;

public class Substring {
	
	public static void main(String[] args) {
		String str="Java Programming";
		System.out.println(str.substring(0, 4)); //Java
		System.out.println(str.substring(0, 8)); //Java Pro
		System.out.println(str.substring(0, 12)); //Java Program
		System.out.println(str.substring(0, 16)); //Java Programming
	}

}
