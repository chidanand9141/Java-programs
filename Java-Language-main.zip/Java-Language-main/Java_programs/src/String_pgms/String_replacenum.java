package String_pgms;

public class String_replacenum {
	
		public static void main(String[] args) {
			String str="H1e2l3l4o g5o6o7d m8o9r1n8i4n7g";
			System.out.println(str.replaceAll("[0-9]"," "));
		}
		}


