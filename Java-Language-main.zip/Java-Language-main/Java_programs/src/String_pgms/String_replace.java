package String_pgms;

public class String_replace {
	public static void main(String[] args) {
		String str="Ring";
		System.out.println(str.replace('R', 'K'));
		
	}

}
