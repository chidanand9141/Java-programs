package String_pgms;

public class String_specialchar {

	public static void main(String[] args) {
		String str="H!e$l#l*o G@o@o!d  M@o!r#n$i*n#g....!";
		System.out.println(str.replaceAll("['!', '#', '*', '$', '@']"," "));
	}
	}



