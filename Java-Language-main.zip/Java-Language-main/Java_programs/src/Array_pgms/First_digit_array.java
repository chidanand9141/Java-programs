package Array_pgms;

import java.util.Arrays;

public class First_digit_array {
	public static void main(String[] args) {
		int arr[]= {10,20,30,40,50};
		Arrays.sort(arr);
		
	//	System.out.println(arr[0]);
		
	//	System.out.println(arr[1]);
		
	//	System.out.println(arr[2]);
		
	//	System.out.println(arr[arr.length-1]);
		
		System.out.println(arr[arr.length-2]);
		
		
	}
	
	

}
