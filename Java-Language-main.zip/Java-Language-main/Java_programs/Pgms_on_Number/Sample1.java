// WAP on Number given Number is perform addition operation
package Pgms_on_Number;

public class Sample1 
{
	static void add(int a, int b)
	{
	  int c;
	  c=a+b;
	  System.out.println("The addition of two numbers is:"+c);
	  
	}
   public static void main(String[] args) 
   {
	   int a=1234;
	   int b=4321;
	   add(a,b);
   }
}
