//WAP on Convert Character to integer and integer to Character 
package Type_casting_pgm;

public class Sample1 
{
   public static void main(String[] args) 
   {
	char ch='a';
	int no=(int)ch+7;
	System.out.println(no);
	
	char ch1=(char)no;
	System.out.println(ch1);
   }
}
