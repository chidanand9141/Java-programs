package swap_pgm;

class Swap_3rd_var
{
  public static void main(String[] args)
  {
	  int a=10;
	  int b=20;
	  int temp;
	  
	      temp=a;
	      a=b;
	      b=temp;
	      
	      System.out.println("The a Contains"+a);
	      System.out.println("The b Contains"+b);
  
  }
}
